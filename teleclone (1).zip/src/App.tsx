import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Paperclip, 
  Mic, 
  Search, 
  User, 
  LogOut, 
  File, 
  Play, 
  Pause, 
  X,
  Plus,
  MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import socket from './lib/socket';

interface UserData {
  id: string;
  username: string;
  displayName: string;
  uniqueId: string;
}

interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  type: 'text' | 'file' | 'voice';
  fileUrl?: string;
  fileName?: string;
  timestamp: string;
}

export default function App() {
  const [user, setUser] = useState<UserData | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [activeChat, setActiveChat] = useState<UserData | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [contacts, setContacts] = useState<UserData[]>([]);
  const [searchId, setSearchId] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Auth State
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser && token) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      socket.emit('register', parsedUser.id);
    }
  }, [token]);

  // Socket Listeners
  useEffect(() => {
    if (!user) return;

    const handleReceiveMessage = (message: Message) => {
      if (activeChat && (message.senderId === activeChat.id || message.receiverId === activeChat.id)) {
        setMessages(prev => [...prev, message]);
      }
      // Update contacts list if new sender
      if (!contacts.find(c => c.id === message.senderId) && message.senderId !== user.id) {
        // Fetch user info or just add to list if we have it
      }
    };

    const handleMessageSent = (message: Message) => {
      setMessages(prev => [...prev, message]);
    };

    socket.on('receive_message', handleReceiveMessage);
    socket.on('message_sent', handleMessageSent);

    return () => {
      socket.off('receive_message', handleReceiveMessage);
      socket.off('message_sent', handleMessageSent);
    };
  }, [user, activeChat, contacts]);

  // Fetch messages when active chat changes
  useEffect(() => {
    if (activeChat && token) {
      fetch(`/api/messages/${activeChat.id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(data => setMessages(data));
    }
  }, [activeChat, token]);

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData);

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const result = await res.json();
      if (res.ok) {
        localStorage.setItem('token', result.token);
        localStorage.setItem('user', JSON.stringify(result.user));
        setToken(result.token);
        setUser(result.user);
        socket.emit('register', result.user.id);
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError('Connection error');
    }
  };

  const handleRegister = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData);

    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const result = await res.json();
      if (res.ok) {
        setIsRegistering(false);
        setError('Registration successful! Please login.');
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError('Connection error');
    }
  };

  const handleSearch = async () => {
    if (!searchId) return;
    try {
      const res = await fetch(`/api/users/search/${searchId.toUpperCase()}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const result = await res.json();
      if (res.ok) {
        if (!contacts.find(c => c.id === result.id)) {
          setContacts(prev => [result, ...prev]);
        }
        setActiveChat(result);
        setSearchId('');
      } else {
        setError('User not found');
      }
    } catch (err) {
      setError('Search error');
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
    setUser(null);
    setActiveChat(null);
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-telegram-blue/10 p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-3xl shadow-xl w-full max-w-md"
        >
          <div className="flex flex-col items-center mb-8">
            <div className="w-20 h-20 bg-telegram-blue rounded-3xl flex items-center justify-center mb-4 shadow-lg">
              <MessageSquare className="text-white w-12 h-12" />
            </div>
            <h1 className="text-3xl font-bold text-gray-800">TeleClone</h1>
            <p className="text-gray-500">Welcome to your messenger</p>
          </div>

          <form onSubmit={isRegistering ? handleRegister : handleLogin} className="space-y-4">
            {isRegistering && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Display Name</label>
                <input name="displayName" type="text" required className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-telegram-blue outline-none transition-all" placeholder="John Doe" />
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
              <input name="username" type="text" required className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-telegram-blue outline-none transition-all" placeholder="johndoe" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input name="password" type="password" required className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-telegram-blue outline-none transition-all" placeholder="••••••••" />
            </div>
            
            {error && <p className="text-red-500 text-sm text-center">{error}</p>}

            <button type="submit" className="w-full bg-telegram-blue text-white py-3 rounded-xl font-bold shadow-lg hover:bg-blue-600 transition-colors">
              {isRegistering ? 'Create Account' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button 
              onClick={() => { setIsRegistering(!isRegistering); setError(''); }}
              className="text-telegram-blue font-medium hover:underline"
            >
              {isRegistering ? 'Already have an account? Sign In' : 'New here? Create an account'}
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-white overflow-hidden">
      {/* Sidebar */}
      <div className="w-80 border-r border-gray-100 flex flex-col bg-white">
        <div className="p-4 border-bottom border-gray-50">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-telegram-blue/10 rounded-full flex items-center justify-center">
                <User className="text-telegram-blue w-6 h-6" />
              </div>
              <div>
                <p className="font-bold text-sm leading-none">{user.displayName}</p>
                <p className="text-xs text-telegram-blue font-mono mt-1">ID: {user.uniqueId}</p>
              </div>
            </div>
            <button onClick={logout} className="p-2 text-gray-400 hover:text-red-500 transition-colors">
              <LogOut size={20} />
            </button>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Search by ID..." 
              className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-telegram-blue/20"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {contacts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-400 p-8 text-center">
              <Search size={48} className="mb-4 opacity-20" />
              <p className="text-sm">Search for someone by their unique ID to start chatting</p>
            </div>
          ) : (
            contacts.map(contact => (
              <button 
                key={contact.id}
                onClick={() => setActiveChat(contact)}
                className={`w-full p-4 flex items-center gap-3 hover:bg-gray-50 transition-colors border-b border-gray-50 ${activeChat?.id === contact.id ? 'bg-telegram-light' : ''}`}
              >
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="text-gray-500" />
                </div>
                <div className="flex-1 text-left overflow-hidden">
                  <div className="flex justify-between items-center">
                    <p className="font-bold truncate">{contact.displayName}</p>
                    <span className="text-[10px] text-gray-400 font-mono">#{contact.uniqueId}</span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">Click to chat</p>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-gray-50 relative">
        {activeChat ? (
          <>
            {/* Chat Header */}
            <div className="h-16 bg-white border-b border-gray-100 flex items-center px-6 justify-between z-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                  <User className="text-gray-500" />
                </div>
                <div>
                  <p className="font-bold leading-none">{activeChat.displayName}</p>
                  <p className="text-xs text-gray-400 mt-1">Unique ID: {activeChat.uniqueId}</p>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-4">
              {messages.map((msg, i) => (
                <MessageBubble key={msg.id || i} message={msg} isOwn={msg.senderId === user.id} />
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <InputArea 
              receiverId={activeChat.id} 
              senderId={user.id} 
              token={token!} 
            />
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-gray-400">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <MessageSquare size={48} className="opacity-20" />
            </div>
            <p>Select a chat to start messaging</p>
          </div>
        )}
      </div>
    </div>
  );
}

function MessageBubble({ message, isOwn }: { message: Message, isOwn: boolean, key?: string | number }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95, x: isOwn ? 20 : -20 }}
      animate={{ opacity: 1, scale: 1, x: 0 }}
      className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}
    >
      <div className={isOwn ? 'chat-bubble-sent' : 'chat-bubble-received'}>
        {message.type === 'text' && <p>{message.content}</p>}
        {message.type === 'file' && (
          <a href={message.fileUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:underline">
            <File size={20} />
            <div className="overflow-hidden">
              <p className="truncate text-sm font-medium">{message.fileName}</p>
              <p className="text-[10px] opacity-70">Click to open</p>
            </div>
          </a>
        )}
        {message.type === 'voice' && (
          <div className="flex items-center gap-3 min-w-[200px]">
            <button 
              onClick={togglePlay}
              className={`w-8 h-8 rounded-full flex items-center justify-center ${isOwn ? 'bg-white/20' : 'bg-telegram-blue/10'}`}
            >
              {isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" />}
            </button>
            <div className="flex-1 h-1 bg-current opacity-20 rounded-full relative">
              <div className="absolute inset-0 bg-current rounded-full w-0" style={{ width: isPlaying ? '100%' : '0%', transition: isPlaying ? 'width 10s linear' : 'none' }} />
            </div>
            <audio 
              ref={audioRef} 
              src={message.fileUrl} 
              onEnded={() => setIsPlaying(false)}
              className="hidden" 
            />
          </div>
        )}
      </div>
      <span className="text-[10px] text-gray-400 mt-1 px-1">
        {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
      </span>
    </motion.div>
  );
}

function InputArea({ receiverId, senderId, token }: { receiverId: string, senderId: string, token: string }) {
  const [text, setText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  const handleSend = () => {
    if (!text.trim()) return;
    socket.emit('send_message', {
      senderId,
      receiverId,
      content: text,
      type: 'text'
    });
    setText('');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      const result = await res.json();
      if (res.ok) {
        socket.emit('send_message', {
          senderId,
          receiverId,
          type: 'file',
          fileUrl: result.fileUrl,
          fileName: result.fileName
        });
      }
    } catch (err) {
      console.error('Upload failed', err);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder.current = new MediaRecorder(stream);
      audioChunks.current = [];

      mediaRecorder.current.ondataavailable = (e) => {
        audioChunks.current.push(e.data);
      };

      mediaRecorder.current.onstop = async () => {
        const audioBlob = new Blob(audioChunks.current, { type: 'audio/webm' });
        const file = new File([audioBlob], 'voice_message.webm', { type: 'audio/webm' });
        
        const formData = new FormData();
        formData.append('file', file);

        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}` },
          body: formData
        });
        const result = await res.json();
        if (res.ok) {
          socket.emit('send_message', {
            senderId,
            receiverId,
            type: 'voice',
            fileUrl: result.fileUrl,
            fileName: 'Voice Message'
          });
        }
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.current.start();
      setIsRecording(true);
      setRecordingTime(0);
      timerRef.current = setInterval(() => setRecordingTime(prev => prev + 1), 1000);
    } catch (err) {
      console.error('Microphone access denied', err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder.current && isRecording) {
      mediaRecorder.current.stop();
      setIsRecording(false);
      clearInterval(timerRef.current);
    }
  };

  return (
    <div className="p-4 bg-white border-t border-gray-100">
      <div className="max-w-4xl mx-auto flex items-end gap-2">
        <div className="flex-1 bg-gray-100 rounded-2xl p-2 flex items-end gap-2 relative">
          <label className="p-2 text-gray-400 hover:text-telegram-blue cursor-pointer transition-colors">
            <Paperclip size={22} />
            <input type="file" className="hidden" onChange={handleFileUpload} />
          </label>
          
          {isRecording ? (
            <div className="flex-1 py-2 px-2 flex items-center justify-between text-red-500 font-medium">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span>Recording... {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}</span>
              </div>
              <button onClick={stopRecording} className="text-gray-400 hover:text-red-500">
                <X size={20} />
              </button>
            </div>
          ) : (
            <textarea 
              rows={1}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Write a message..."
              className="flex-1 bg-transparent border-none outline-none py-2 px-1 resize-none max-h-32 text-sm"
            />
          )}
        </div>

        <div className="flex items-center gap-2">
          {text.trim() ? (
            <button 
              onClick={handleSend}
              className="w-12 h-12 bg-telegram-blue text-white rounded-full flex items-center justify-center shadow-lg hover:bg-blue-600 transition-all"
            >
              <Send size={20} />
            </button>
          ) : (
            <button 
              onMouseDown={startRecording}
              onMouseUp={stopRecording}
              className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-all ${isRecording ? 'bg-red-500 text-white scale-110' : 'bg-telegram-blue text-white hover:bg-blue-600'}`}
            >
              <Mic size={20} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
